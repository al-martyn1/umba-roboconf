Robot Configuration Extraction Tool version 0.9
Windows/x86
Built with MSVC v19.16.27049 compiler
Built at Jun 19 2024 22:35:48
Built at Jun 19 2024 22:35:48

Usage: roboconf [OPTIONS] input_file [output_file]

Options:

-h
-?
--help
    Show this help.
