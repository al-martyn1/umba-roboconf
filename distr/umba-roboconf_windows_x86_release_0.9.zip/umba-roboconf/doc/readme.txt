Robot Configuration Extraction Tool version 0.9
Built with MSVC
