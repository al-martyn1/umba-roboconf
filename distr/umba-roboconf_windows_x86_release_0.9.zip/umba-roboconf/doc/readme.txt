Robot Configuration Extraction Tool version 0.9
Built at May 13 2024 22:21:55

Usage: roboconf [OPTIONS] input_file [output_file]

Options:

-h
-?
--help
    Show this help.
    See also RTC RFC010 for details (http://wiki.dep111.rtc.local/rfcrtc:rfcrtc010).
